# Hosted Link: https://eternalcoderss.github.io/Todolist_FE/
# Todo-List
A TODO list made with HTML, CSS, and JavaScript is a basic tool for organizing tasks. Users can add, delete, and mark tasks as complete. The interface includes a form for inputting tasks and a list for displaying them. JavaScript adds functionality like updating task status and filtering tasks.
# Todolist_FE
